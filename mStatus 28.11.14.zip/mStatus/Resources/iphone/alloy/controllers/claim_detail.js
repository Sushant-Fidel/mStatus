function __processArg(obj, key) {
    var arg = null;
    if (obj) {
        arg = obj[key] || null;
        delete obj[key];
    }
    return arg;
}

function Controller() {
    function onLoad() {
        $.claimID.text = claim["data"]["claim"]["claim_id"];
        $.claimName.text = claim["data"]["claim"]["adjuster__first_name"];
        $.add.text = claim["data"]["claim"]["customer_address"];
        $.company.text = claim["data"]["claim"]["vanline__name"];
    }
    function selectImg() {
        var claimID = claim["data"]["claim"]["claim_id"];
        var dialog = Titanium.UI.createOptionDialog({
            title: "Choose an image source...",
            options: [ "Camera", "Photo Gallery", "Cancel" ],
            cancel: 2
        });
        dialog.addEventListener("click", function(e) {
            0 == e.index ? Titanium.Media.showCamera({
                success: function(event) {
                    var image = event.media;
                    if (event.mediaType == Ti.Media.MEDIA_TYPE_PHOTO) {
                        var cameraimg = Titanium.Filesystem.getFile(getClaimFolder(claimID).nativePath, getImageName(claimID));
                        cameraimg.write(image);
                    }
                },
                cancel: function() {
                    alert("you are quit from camera.");
                },
                error: function(error) {
                    var a = Titanium.UI.createAlertDialog({
                        title: "Camera"
                    });
                    a.setMessage(error.code == Titanium.Media.NO_CAMERA ? "Device does not have camera" : "Unexpected error: " + error.code);
                    a.show();
                },
                allowImageEditing: true
            }) : 1 == e.index && Titanium.Media.openPhotoGallery({
                success: function(event) {
                    var image = event.media;
                    if (event.mediaType == Ti.Media.MEDIA_TYPE_PHOTO) {
                        var gallryimg = Titanium.Filesystem.getFile(getClaimFolder(claimID).nativePath, getImageName(claimID));
                        var newBlob = image.imageAsResized(300, 300);
                        Ti.API.info("newBlob size:" + newBlob.size);
                        gallryimg.write(newBlob);
                        var path = gallryimg.resolve();
                        alert(path + "\n This is the path of gallery image");
                    }
                },
                cancel: function() {}
            });
        });
        dialog.show();
    }
    function getImageName(claimID) {
        var fileName;
        var i = 1;
        while (true) {
            var tempName = claimID + "_" + i;
            var tempPath = Titanium.Filesystem.getFile(getClaimFolder(claimID).nativePath, tempName);
            if (!tempPath.exists()) {
                fileName = tempName;
                break;
            }
            i++;
        }
        return fileName;
    }
    function archiveClaim() {
        var claimID = claim["data"]["claim"]["claim_id"];
        var response = claim;
        Ti.API.info("Claim text: " + response);
        var f = Ti.Filesystem.getFile(getClaimFolder(claimID).nativePath, "ClaimInfo.txt");
        f.write(JSON.stringify(response));
        alert(f.resolve());
    }
    function getClaimFolder(claimID) {
        var claimsDir = getClaimsFolder();
        var claimInfoDir = Titanium.Filesystem.getFile(claimsDir.nativePath, claimID);
        claimInfoDir.exists() || claimInfoDir.createDirectory();
        return claimInfoDir;
    }
    function getClaimsFolder() {
        var appDir = Titanium.Filesystem.getFile(Titanium.Filesystem.applicationDataDirectory, "mStatus");
        appDir.exists() || appDir.createDirectory();
        var claimsDir = Titanium.Filesystem.getFile(appDir.nativePath, "Claims");
        claimsDir.exists() || claimsDir.createDirectory();
        return claimsDir;
    }
    require("alloy/controllers/BaseController").apply(this, Array.prototype.slice.call(arguments));
    this.__controllerPath = "claim_detail";
    if (arguments[0]) {
        {
            __processArg(arguments[0], "__parentSymbol");
        }
        {
            __processArg(arguments[0], "$model");
        }
        {
            __processArg(arguments[0], "__itemTemplate");
        }
    }
    var $ = this;
    var exports = {};
    var __defers = {};
    $.__views.claim_detail = Ti.UI.createWindow({
        backgroundColor: "#FFFFFF",
        id: "claim_detail"
    });
    $.__views.claim_detail && $.addTopLevelView($.__views.claim_detail);
    $.__views.__alloyId0 = Ti.UI.createView({
        layout: "vertical",
        top: "64",
        id: "__alloyId0"
    });
    $.__views.claim_detail.add($.__views.__alloyId0);
    $.__views.__alloyId1 = Ti.UI.createView({
        backgroundColor: "#11000000",
        width: "100%",
        height: "50",
        id: "__alloyId1"
    });
    $.__views.__alloyId0.add($.__views.__alloyId1);
    $.__views.__alloyId2 = Ti.UI.createLabel({
        width: "40%",
        text: "Claim ID",
        height: "50%",
        left: "5%",
        top: "25%",
        font: {
            fontFamily: "Arial",
            fontWeight: "bold",
            fontSize: 14
        },
        id: "__alloyId2"
    });
    $.__views.__alloyId1.add($.__views.__alloyId2);
    $.__views.claimID = Ti.UI.createLabel({
        width: "55%",
        height: "50%",
        left: "45%",
        top: "25%",
        font: {
            fontFamily: "Arial",
            fontWeight: "bold",
            fontSize: 14
        },
        id: "claimID"
    });
    $.__views.__alloyId1.add($.__views.claimID);
    $.__views.__alloyId3 = Ti.UI.createView({
        backgroundColor: "#00000000",
        width: "100%",
        height: "50",
        id: "__alloyId3"
    });
    $.__views.__alloyId0.add($.__views.__alloyId3);
    $.__views.__alloyId4 = Ti.UI.createLabel({
        width: "40%",
        text: "Name",
        height: "50%",
        left: "5%",
        top: "25%",
        font: {
            fontFamily: "Arial",
            fontWeight: "bold",
            fontSize: 14
        },
        id: "__alloyId4"
    });
    $.__views.__alloyId3.add($.__views.__alloyId4);
    $.__views.claimName = Ti.UI.createLabel({
        width: "55%",
        height: "50%",
        left: "45%",
        top: "25%",
        font: {
            fontFamily: "Arial",
            fontWeight: "bold",
            fontSize: 14
        },
        id: "claimName"
    });
    $.__views.__alloyId3.add($.__views.claimName);
    $.__views.__alloyId5 = Ti.UI.createView({
        backgroundColor: "#11000000",
        width: "100%",
        height: "50",
        id: "__alloyId5"
    });
    $.__views.__alloyId0.add($.__views.__alloyId5);
    $.__views.__alloyId6 = Ti.UI.createLabel({
        width: "40%",
        text: "Customer Address",
        height: "50%",
        left: "5%",
        top: "25%",
        font: {
            fontFamily: "Arial",
            fontWeight: "bold",
            fontSize: 14
        },
        id: "__alloyId6"
    });
    $.__views.__alloyId5.add($.__views.__alloyId6);
    $.__views.add = Ti.UI.createLabel({
        width: "55%",
        height: "50%",
        left: "45%",
        top: "25%",
        font: {
            fontFamily: "Arial",
            fontWeight: "bold",
            fontSize: 14
        },
        id: "add"
    });
    $.__views.__alloyId5.add($.__views.add);
    $.__views.__alloyId7 = Ti.UI.createView({
        backgroundColor: "#00000000",
        width: "100%",
        height: "50",
        id: "__alloyId7"
    });
    $.__views.__alloyId0.add($.__views.__alloyId7);
    $.__views.__alloyId8 = Ti.UI.createLabel({
        width: "40%",
        text: "Vanline",
        height: "50%",
        left: "5%",
        top: "25%",
        font: {
            fontFamily: "Arial",
            fontWeight: "bold",
            fontSize: 14
        },
        id: "__alloyId8"
    });
    $.__views.__alloyId7.add($.__views.__alloyId8);
    $.__views.company = Ti.UI.createLabel({
        width: "55%",
        height: "50%",
        left: "45%",
        top: "25%",
        font: {
            fontFamily: "Arial",
            fontWeight: "bold",
            fontSize: 14
        },
        id: "company"
    });
    $.__views.__alloyId7.add($.__views.company);
    $.__views.__alloyId9 = Ti.UI.createButton({
        title: "Capture",
        bottom: 30,
        width: 90,
        height: 35,
        borderRadius: 1,
        font: {
            fontFamily: "Arial",
            fontWeight: "bold",
            fontSize: 14
        },
        id: "__alloyId9"
    });
    $.__views.claim_detail.add($.__views.__alloyId9);
    selectImg ? $.__views.__alloyId9.addEventListener("click", selectImg) : __defers["$.__views.__alloyId9!click!selectImg"] = true;
    $.__views.__alloyId10 = Ti.UI.createButton({
        title: "Archive",
        bottom: 30,
        width: 90,
        left: 50,
        height: 35,
        borderRadius: 1,
        font: {
            fontFamily: "Arial",
            fontWeight: "bold",
            fontSize: 14
        },
        id: "__alloyId10"
    });
    $.__views.claim_detail.add($.__views.__alloyId10);
    archiveClaim ? $.__views.__alloyId10.addEventListener("click", archiveClaim) : __defers["$.__views.__alloyId10!click!archiveClaim"] = true;
    exports.destroy = function() {};
    _.extend($, $.__views);
    Titanium.App.Properties.getString("SessionKey");
    var claim = JSON.parse(Titanium.App.Properties.getString("Arguments")).value;
    Titanium.App.Properties.setString("Arguments", null);
    $.claim_detail.open();
    onLoad();
    __defers["$.__views.__alloyId9!click!selectImg"] && $.__views.__alloyId9.addEventListener("click", selectImg);
    __defers["$.__views.__alloyId10!click!archiveClaim"] && $.__views.__alloyId10.addEventListener("click", archiveClaim);
    _.extend($, exports);
}

var Alloy = require("alloy"), Backbone = Alloy.Backbone, _ = Alloy._;

module.exports = Controller;