function __processArg(obj, key) {
    var arg = null;
    if (obj) {
        arg = obj[key] || null;
        delete obj[key];
    }
    return arg;
}

function Controller() {
    function onLoad() {
        var url = "http://www.promustech.com/api/v1/claims?s=my_claims&sort=date";
        var client = Ti.Network.createHTTPClient({
            onload: function() {
                Ti.API.info("Received text: " + this.responseText);
                var response = JSON.parse(this.responseText);
                dataSuccess(response);
            },
            onerror: function(e) {
                alert("error");
                Ti.API.debug(e.error);
            },
            timeout: 5e4
        });
        client.open("GET", url);
        client.setRequestHeader("Authentication", "Token " + token);
        client.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        client.send();
    }
    function dataSuccess(response) {
        claims = response["data"]["claims"];
        var claimIDs = [];
        var date_resisterd = [];
        var company = [];
        var adjuster_name = [];
        for (i in claims) {
            claimIDs.push(claims[i]["claim_id"]);
            date_resisterd.push(claims[i]["date_received"]);
            company.push(claims[i]["vanline_company"]);
            adjuster_name.push(claims[i]["adjuster_first"]);
        }
        var commonIDs = preSetData(claimIDs);
        for (var i = 0; i < claimIDs.length && 10 > i; i++) {
            var row = Ti.UI.createTableViewRow({
                height: 100,
                backgroundColor: i % 2 == 0 ? "#C0C0C0" : "white"
            });
            var image = Titanium.UI.createImageView({
                image: "/images/archive.png",
                top: 40,
                right: 10,
                height: 30,
                width: 30
            });
            var exists = false;
            for (var j = 0; j < commonIDs.length; j++) if (claimIDs[i] == commonIDs[j]) {
                exists = true;
                break;
            }
            exists || (image.visible = false);
            var restLabel = Ti.UI.createLabel({
                text: claimIDs[i],
                height: "auto",
                left: 10,
                top: 20,
                font: {
                    fontSize: 20
                }
            });
            var restLabel_date = Ti.UI.createLabel({
                text: date_resisterd[i],
                height: "auto",
                left: 10,
                top: 60,
                font: {
                    fontSize: 20
                }
            });
            var restLabel_name = Ti.UI.createLabel({
                text: adjuster_name[i],
                height: "auto",
                left: 250,
                top: 20,
                font: {
                    fontSize: 20
                }
            });
            var restLabel_vanline = Ti.UI.createLabel({
                text: company[i],
                height: "auto",
                left: 250,
                top: 60,
                font: {
                    fontSize: 20
                }
            });
            row.add(restLabel_name);
            row.add(restLabel);
            row.add(restLabel_date);
            row.add(restLabel_vanline);
            row.add(image);
            data.push(row);
        }
        $.table.setData(data);
    }
    function preSetData(claimIDs) {
        var dir_files = getClaimsFolder().getDirectoryListing();
        var commanData = [];
        for (var i = 0; i < dir_files.length; i++) {
            var pastClaim = dir_files[i];
            for (var j = 0; j < claimIDs.length; j++) {
                var serverClaim = claimIDs[j];
                if (serverClaim === pastClaim) {
                    commanData.push(serverClaim);
                    break;
                }
            }
        }
        return commanData;
    }
    function tableOnClick(e) {
        var index = e.index;
        var claimID = claims[index]["claim_id"];
        var url = "http://www.promustech.com/api/v1/claims/" + claimID + "&fields=progress";
        var client = Ti.Network.createHTTPClient({
            onload: function() {
                Ti.API.info("Received text: " + this.responseText);
                var response = JSON.parse(this.responseText);
                var args = {
                    name: "claim_detail",
                    value: response
                };
                Titanium.App.Properties.setString("Arguments", JSON.stringify(args));
                var claimDitail = Alloy.createController("claim_detail").getView();
                Titanium.UI.iOS.createNavigationWindow(claimDitail);
            },
            onerror: function(e) {
                alert("error");
                Ti.API.debug(e.error);
            },
            timeout: 5e4
        });
        client.open("GET", url);
        client.setRequestHeader("Authentication", "Token " + token);
        client.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        client.send();
    }
    function getClaimsFolder() {
        var appDir = Titanium.Filesystem.getFile(Titanium.Filesystem.applicationDataDirectory, "mStatus");
        appDir.exists() || appDir.createDirectory();
        var claimsDir = Titanium.Filesystem.getFile(appDir.nativePath, "Claims");
        claimsDir.exists() || claimsDir.createDirectory();
        return claimsDir;
    }
    require("alloy/controllers/BaseController").apply(this, Array.prototype.slice.call(arguments));
    this.__controllerPath = "claimlist";
    if (arguments[0]) {
        {
            __processArg(arguments[0], "__parentSymbol");
        }
        {
            __processArg(arguments[0], "$model");
        }
        {
            __processArg(arguments[0], "__itemTemplate");
        }
    }
    var $ = this;
    var exports = {};
    var __defers = {};
    $.__views.claimlist = Ti.UI.createWindow({
        backgroundColor: "white",
        id: "claimlist"
    });
    $.__views.claimlist && $.addTopLevelView($.__views.claimlist);
    $.__views.table = Ti.UI.createTableView({
        id: "table"
    });
    $.__views.claimlist.add($.__views.table);
    tableOnClick ? $.__views.table.addEventListener("click", tableOnClick) : __defers["$.__views.table!click!tableOnClick"] = true;
    exports.destroy = function() {};
    _.extend($, $.__views);
    var token = Titanium.App.Properties.getString("SessionKey");
    var claims = [];
    var data = [];
    $.claimlist.open();
    onLoad();
    __defers["$.__views.table!click!tableOnClick"] && $.__views.table.addEventListener("click", tableOnClick);
    _.extend($, exports);
}

var Alloy = require("alloy"), Backbone = Alloy.Backbone, _ = Alloy._;

module.exports = Controller;