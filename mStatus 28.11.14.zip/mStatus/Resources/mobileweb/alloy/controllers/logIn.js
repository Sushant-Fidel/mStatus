function __processArg(obj, key) {
    var arg = null;
    if (obj) {
        arg = obj[key] || null;
        delete obj[key];
    }
    return arg;
}

function Controller() {
    function doClick() {
        alert($.label.text);
    }
    require("alloy/controllers/BaseController").apply(this, Array.prototype.slice.call(arguments));
    this.__controllerPath = "logIn";
    if (arguments[0]) {
        __processArg(arguments[0], "__parentSymbol");
        __processArg(arguments[0], "$model");
        __processArg(arguments[0], "__itemTemplate");
    }
    var $ = this;
    var exports = {};
    var __defers = {};
    $.__views.logIn = Ti.UI.createWindow({
        id: "logIn"
    });
    $.__views.logIn && $.addTopLevelView($.__views.logIn);
    $.__views.__alloyId0 = Ti.UI.createLabel({
        text: "User Name:",
        id: "__alloyId0"
    });
    $.__views.logIn.add($.__views.__alloyId0);
    $.__views.__alloyId1 = Ti.UI.createLabel({
        text: "Passward:",
        id: "__alloyId1"
    });
    $.__views.logIn.add($.__views.__alloyId1);
    $.__views.userName = Ti.UI.createTextField({
        id: "userName"
    });
    $.__views.logIn.add($.__views.userName);
    $.__views.password = Ti.UI.createTextField({
        id: "password"
    });
    $.__views.logIn.add($.__views.password);
    $.__views.loginButton = Ti.UI.createButton({
        title: "login",
        id: "loginButton"
    });
    $.__views.logIn.add($.__views.loginButton);
    doClick ? $.__views.loginButton.addEventListener("click", doClick) : __defers["$.__views.loginButton!click!doClick"] = true;
    exports.destroy = function() {};
    _.extend($, $.__views);
    $.logIn.open();
    __defers["$.__views.loginButton!click!doClick"] && $.__views.loginButton.addEventListener("click", doClick);
    _.extend($, exports);
}

var Alloy = require("alloy"), Backbone = Alloy.Backbone, _ = Alloy._;

module.exports = Controller;