function __processArg(obj, key) {
    var arg = null;
    if (obj) {
        arg = obj[key] || null;
        delete obj[key];
    }
    return arg;
}

function Controller() {
    require("alloy/controllers/BaseController").apply(this, Array.prototype.slice.call(arguments));
    this.__controllerPath = "logIn_UI";
    if (arguments[0]) {
        __processArg(arguments[0], "__parentSymbol");
        __processArg(arguments[0], "$model");
        __processArg(arguments[0], "__itemTemplate");
    }
    var $ = this;
    var exports = {};
    var __defers = {};
    $.__views.logIn_UI = Ti.UI.createWindow({
        id: "logIn_UI"
    });
    $.__views.logIn_UI && $.addTopLevelView($.__views.logIn_UI);
    $.__views.__alloyId0 = Ti.UI.createView({
        layout: "vertical",
        id: "__alloyId0"
    });
    $.__views.logIn_UI.add($.__views.__alloyId0);
    $.__views.labl1 = Ti.UI.createLabel({
        text: "User Name:",
        id: "labl1"
    });
    $.__views.__alloyId0.add($.__views.labl1);
    $.__views.labl2 = Ti.UI.createLabel({
        text: "Passward:",
        id: "labl2"
    });
    $.__views.__alloyId0.add($.__views.labl2);
    $.__views.userInput = Ti.UI.createTextField({
        id: "userInput"
    });
    $.__views.__alloyId0.add($.__views.userInput);
    $.__views.pwdInput = Ti.UI.createTextField({
        id: "pwdInput"
    });
    $.__views.__alloyId0.add($.__views.pwdInput);
    $.__views.loginButton = Ti.UI.createButton({
        title: "login",
        id: "loginButton"
    });
    $.__views.__alloyId0.add($.__views.loginButton);
    doClick ? $.__views.loginButton.addEventListener("click", doClick) : __defers["$.__views.loginButton!click!doClick"] = true;
    exports.destroy = function() {};
    _.extend($, $.__views);
    __defers["$.__views.loginButton!click!doClick"] && $.__views.loginButton.addEventListener("click", doClick);
    _.extend($, exports);
}

var Alloy = require("alloy"), Backbone = Alloy.Backbone, _ = Alloy._;

module.exports = Controller;