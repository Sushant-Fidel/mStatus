function __processArg(obj, key) {
    var arg = null;
    if (obj) {
        arg = obj[key] || null;
        delete obj[key];
    }
    return arg;
}

function Controller() {
    function doClick() {
        var client = Ti.Network.createHTTPClient({
            onload: function() {
                Ti.API.info("Received text: " + this.responseText);
                var response = JSON.parse(this.responseText);
                var usertoken = response["data"]["user"]["user_token"];
                Titanium.App.Properties.setString("SessionKey", usertoken);
                var args = {
                    name: "test name",
                    value: "VALID"
                };
                Titanium.App.Properties.setString("Arguments", args);
                var claiml = Alloy.createController("claimlist").getView();
                claiml.open();
            },
            onerror: function(e) {
                alert("error");
                Ti.API.debug(e.error);
            },
            timeout: 5e4
        });
        var url = "http://www.promustech.com/api/v1/login";
        client.open("POST", url);
        client.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        var args = {
            username: "1200",
            password: "TempPass951"
        };
        client.send(JSON.stringify(args));
    }
    require("alloy/controllers/BaseController").apply(this, Array.prototype.slice.call(arguments));
    this.__controllerPath = "logIn";
    if (arguments[0]) {
        {
            __processArg(arguments[0], "__parentSymbol");
        }
        {
            __processArg(arguments[0], "$model");
        }
        {
            __processArg(arguments[0], "__itemTemplate");
        }
    }
    var $ = this;
    var exports = {};
    var __defers = {};
    $.__views.logIn = Ti.UI.createWindow({
        backgroundColor: "white",
        id: "logIn"
    });
    $.__views.logIn && $.addTopLevelView($.__views.logIn);
    $.__views.Username = Ti.UI.createTextField({
        color: "#336699",
        top: 10,
        left: 10,
        width: 300,
        height: 40,
        hintText: "Username",
        keyboardType: Titanium.UI.KEYBOARD_DEFAULT,
        returnKeyType: Titanium.UI.RETURNKEY_DEFAULT,
        borderStyle: Titanium.UI.INPUT_BORDERSTYLE_ROUNDED,
        id: "Username"
    });
    $.__views.logIn.add($.__views.Username);
    $.__views.Password = Ti.UI.createTextField({
        color: "#336699",
        top: 60,
        left: 10,
        width: 300,
        height: 40,
        hintText: "Password",
        passwordMask: true,
        keyboardType: Titanium.UI.KEYBOARD_DEFAULT,
        returnKeyType: Titanium.UI.RETURNKEY_DEFAULT,
        borderStyle: Titanium.UI.INPUT_BORDERSTYLE_ROUNDED,
        id: "Password"
    });
    $.__views.logIn.add($.__views.Password);
    $.__views.loginButton = Ti.UI.createButton({
        title: "login",
        top: 110,
        width: 90,
        height: 35,
        borderRadius: 1,
        font: {
            fontFamily: "Arial",
            fontWeight: "bold",
            fontSize: 14
        },
        id: "loginButton"
    });
    $.__views.logIn.add($.__views.loginButton);
    doClick ? $.__views.loginButton.addEventListener("click", doClick) : __defers["$.__views.loginButton!click!doClick"] = true;
    exports.destroy = function() {};
    _.extend($, $.__views);
    $.logIn.open();
    __defers["$.__views.loginButton!click!doClick"] && $.__views.loginButton.addEventListener("click", doClick);
    _.extend($, exports);
}

var Alloy = require("alloy"), Backbone = Alloy.Backbone, _ = Alloy._;

module.exports = Controller;