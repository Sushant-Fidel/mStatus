function __processArg(obj, key) {
    var arg = null;
    if (obj) {
        arg = obj[key] || null;
        delete obj[key];
    }
    return arg;
}

function Controller() {
    function selectImg(claimID) {
        var dialog = Titanium.UI.createOptionDialog({
            title: "Choose an image source...",
            options: [ "Camera", "Photo Gallery", "Cancel" ],
            cancel: 2
        });
        dialog.addEventListener("click", function(e) {
            0 == e.index ? Titanium.Media.showCamera({
                success: function(event) {
                    var image = event.media;
                    if (event.mediaType == Ti.Media.MEDIA_TYPE_PHOTO) {
                        var cameraimg = Titanium.Filesystem.getFile(getClaimFolder(claimID).nativePath, getImageName(claimID));
                        cameraimg.write(image);
                    }
                },
                cancel: function() {
                    alert("you are quit from camera.");
                },
                error: function(error) {
                    var a = Titanium.UI.createAlertDialog({
                        title: "Camera"
                    });
                    a.setMessage(error.code == Titanium.Media.NO_CAMERA ? "Device does not have camera" : "Unexpected error: " + error.code);
                    a.show();
                },
                allowImageEditing: true
            }) : 1 == e.index && Titanium.Media.openPhotoGallery({
                success: function(event) {
                    var image = event.media;
                    if (event.mediaType == Ti.Media.MEDIA_TYPE_PHOTO) {
                        var gallryimg = Titanium.Filesystem.getFile(getClaimFolder(claimID).nativePath, getImageName(claimID));
                        var newBlob = image.imageAsResized(300, 300);
                        Ti.API.info("newBlob size:" + newBlob.size);
                        gallryimg.write(newBlob);
                        {
                            gallryimg.resolve();
                        }
                    }
                },
                cancel: function() {}
            });
        });
        dialog.show();
    }
    function getImageName(claimID) {
        var fileName;
        var i = 1;
        while (true) {
            var tempName = claimID + "_" + i;
            var tempPath = Titanium.Filesystem.getFile(getClaimFolder(claimID).nativePath, tempName);
            if (!tempPath.exists()) {
                fileName = tempName;
                break;
            }
            i++;
        }
        return fileName;
    }
    function getClaimFolder(claimID) {
        var claimsDir = getClaimsFolder();
        var claimInfoDir = Titanium.Filesystem.getFile(claimsDir.nativePath, claimID);
        claimInfoDir.exists() || claimInfoDir.createDirectory();
        return claimInfoDir;
    }
    function getClaimsFolder() {
        var appDir = Titanium.Filesystem.getFile(Titanium.Filesystem.applicationDataDirectory, "mStatus");
        appDir.exists() || appDir.createDirectory();
        var claimsDir = Titanium.Filesystem.getFile(appDir.nativePath, "Claims");
        claimsDir.exists() || claimsDir.createDirectory();
        return claimsDir;
    }
    require("alloy/controllers/BaseController").apply(this, Array.prototype.slice.call(arguments));
    this.__controllerPath = "claim_detail";
    if (arguments[0]) {
        {
            __processArg(arguments[0], "__parentSymbol");
        }
        {
            __processArg(arguments[0], "$model");
        }
        {
            __processArg(arguments[0], "__itemTemplate");
        }
    }
    var $ = this;
    var exports = {};
    var __defers = {};
    $.__views.claim_detail = Ti.UI.createWindow({
        backgroundColor: "cyan",
        id: "claim_detail"
    });
    $.__views.claim_detail && $.addTopLevelView($.__views.claim_detail);
    $.__views.__alloyId0 = Ti.UI.createButton({
        title: "Capture",
        bottom: 10,
        width: 90,
        height: 35,
        borderRadius: 1,
        font: {
            fontFamily: "Arial",
            fontWeight: "bold",
            fontSize: 14
        },
        id: "__alloyId0"
    });
    $.__views.claim_detail.add($.__views.__alloyId0);
    selectImg ? $.__views.__alloyId0.addEventListener("click", selectImg) : __defers["$.__views.__alloyId0!click!selectImg"] = true;
    $.__views.__alloyId1 = Ti.UI.createLabel({
        width: Ti.UI.SIZE,
        height: Ti.UI.SIZE,
        left: "20%",
        top: "15%",
        font: {
            fontFamily: "Arial",
            fontWeight: "bold",
            fontSize: 14
        },
        text: "claim ID:",
        id: "__alloyId1"
    });
    $.__views.claim_detail.add($.__views.__alloyId1);
    $.__views.__alloyId2 = Ti.UI.createLabel({
        width: Ti.UI.SIZE,
        height: Ti.UI.SIZE,
        left: "20%",
        top: "25%",
        font: {
            fontFamily: "Arial",
            fontWeight: "bold",
            fontSize: 14
        },
        text: "claim Name:",
        id: "__alloyId2"
    });
    $.__views.claim_detail.add($.__views.__alloyId2);
    $.__views.scrollView = Ti.UI.createScrollView({
        id: "scrollView",
        showHorizontalScrollIndicator: "true",
        height: "20%",
        width: "90%"
    });
    $.__views.claim_detail.add($.__views.scrollView);
    $.__views.view = Ti.UI.createView({
        id: "view",
        backgroundColor: "#336699",
        borderRadius: "10",
        bottom: "30",
        height: "200",
        width: "1000"
    });
    $.__views.scrollView.add($.__views.view);
    exports.destroy = function() {};
    _.extend($, $.__views);
    Titanium.App.Properties.getString("Arguments");
    $.claim_detail.open();
    __defers["$.__views.__alloyId0!click!selectImg"] && $.__views.__alloyId0.addEventListener("click", selectImg);
    _.extend($, exports);
}

var Alloy = require("alloy"), Backbone = Alloy.Backbone, _ = Alloy._;

module.exports = Controller;