$.index.open();

Titanium.App.Properties.setString("Arguments", null);

var login = Alloy.createController('logIn').getView();
if (OS_IOS) {
	Titanium.UI.iOS.createNavigationWindow(login);
} else if (OS_ANDROID) {
	login.open();
}
