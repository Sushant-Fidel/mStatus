		 
function doClick(d) {

	var client = Ti.Network.createHTTPClient({
		// function called when the response data is available
		onload : function(e) {
			Ti.API.info("Received text: " + this.responseText);
			var response = JSON.parse(this.responseText);

			var usertoken = ((response["data"])["user"])["user_token"];
			Titanium.App.Properties.setString("SessionKey", usertoken);

			//navigation to claimlist
			var claiml = Alloy.createController('claimlist').getView();
			if (OS_IOS) {
				Titanium.UI.iOS.createNavigationWindow(claiml);
			}
			if (OS_ANDROID) {
				claiml.open();
			}
		},

		// function called when an error occurs, including a timeout
		onerror : function(e) {
			alert('error');
			Ti.API.debug(e.error);
		},
		timeout : 50000 /* in milliseconds */
	});

	var url = "http://www.promustech.com/api/v1/login";
	client.open('POST', url);
	client.setRequestHeader("Content-Type", "application/json; charset=utf-8");
	// Send the request.
	var args = {
		//hard code user input
		username : "1200",
		password : "TempPass951"
		//dynamic user input
		// username : $.Username.value,
		// password : $.Password.value,

	};
	client.send(JSON.stringify(args));
}

$.logIn.open();