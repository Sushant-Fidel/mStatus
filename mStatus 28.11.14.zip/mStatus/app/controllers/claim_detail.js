var token = Titanium.App.Properties.getString("SessionKey");
var claim = JSON.parse(Titanium.App.Properties.getString("Arguments")).value;

Titanium.App.Properties.setString("Arguments", null);

function onLoad() {
	$.claimID.text = ((claim["data"])["claim"])["claim_id"];
	$.claimName.text = ((claim["data"])["claim"])["adjuster__first_name"];
	$.add.text = ((claim["data"])["claim"])["customer_address"];
	$.company.text = ((claim["data"])["claim"])["vanline__name"];
}

function selectImg(d) {
	var claimID = ((claim["data"])["claim"])["claim_id"];
	
	var dialog = Titanium.UI.createOptionDialog({
		title : 'Choose an image source...',
		options : ['Camera', 'Photo Gallery', 'Cancel'],
		cancel : 2
	});

	dialog.addEventListener('click', function(e) {
		//if first option was selected
		if (e.index == 0) {
			//then we are getting image from camera
			Titanium.Media.showCamera({
				//we got something
				success : function(event) {
					//getting media
					var image = event.media;
					//checking if it is photo
					if (event.mediaType == Ti.Media.MEDIA_TYPE_PHOTO) {
						var cameraimg = Titanium.Filesystem.getFile(getClaimFolder(claimID).nativePath, getImageName(claimID));
						cameraimg.write(image);
					}
				},
				cancel : function() {
					alert("you are quit from camera.");
					//do somehting if user cancels operation
				},
				error : function(error) {
					//error happend, create alert
					var a = Titanium.UI.createAlertDialog({
						title : 'Camera'
					});
					//set message
					if (error.code == Titanium.Media.NO_CAMERA) {
						a.setMessage('Device does not have camera');
					} else {
						a.setMessage('Unexpected error: ' + error.code);
					}
					// show alert
					a.show();
				},
				allowImageEditing : true
			});
		} else if (e.index == 1) {
			//obtain an image from the gallery
			Titanium.Media.openPhotoGallery({
				success : function(event) {
					//getting media
					var image = event.media;
					// set image view

					//checking if it is photo
					if (event.mediaType == Ti.Media.MEDIA_TYPE_PHOTO) {
						//we may create image view with contents from image variable
						//or simply save path to image
						var gallryimg = Titanium.Filesystem.getFile(getClaimFolder(claimID).nativePath, getImageName(claimID));
						// original image taken fron gallery & write in file System. .size give size of original image
						// gallryimg.write(image);
						// alert("original size:" + image.size);
						// original image is resized to 300*300 by using imageAsResized
						var newBlob = image.imageAsResized(300, 300);
						Ti.API.info("newBlob size:" + newBlob.size);
						// alert("newBlob size:" + newBlob.size);
						gallryimg.write(newBlob);
						var path = gallryimg.resolve();
						//get the path of image stored in file system
						alert(path + "\n This is the path of gallery image");
					}
				},

				cancel : function() {
					//user cancelled the action fron within
					//the photo gallery
				}
			});
		} else {
			//cancel was tapped
			//user opted not to choose a photo
		}
	});

	//show dialog
	dialog.show();
}

function getImageName(claimID) {
	var fileName;
	var i = 1;
	while (true) {
		var tempName = claimID + '_' + i;
		var tempPath = Titanium.Filesystem.getFile(getClaimFolder(claimID).nativePath, tempName);
		if (!tempPath.exists()) {
			fileName = tempName;
			break;
		}
		i++;
	};
	return fileName;
}

function archiveClaim(e) {
	var claimID = ((claim["data"])["claim"])["claim_id"];
	var response = claim;
	Ti.API.info("Claim text: " + response);
	var f = Ti.Filesystem.getFile(getClaimFolder(claimID).nativePath, 'ClaimInfo.txt');
	f.write(JSON.stringify(response));
	alert(f.resolve());
}

function getClaimFolder(claimID) {
	var claimsDir = getClaimsFolder();
	var claimInfoDir = Titanium.Filesystem.getFile(claimsDir.nativePath, claimID);
	if (!claimInfoDir.exists()) {
		claimInfoDir.createDirectory();
	}

	return claimInfoDir;
}

function getClaimsFolder() {
	var appDir = Titanium.Filesystem.getFile(Titanium.Filesystem.applicationDataDirectory, 'mStatus');
	if (!appDir.exists()) {
		appDir.createDirectory();
	}
	var claimsDir = Titanium.Filesystem.getFile(appDir.nativePath, 'Claims');
	if (!claimsDir.exists()) {
		claimsDir.createDirectory();
	}
	
	return claimsDir;
}

$.claim_detail.open();
onLoad();
