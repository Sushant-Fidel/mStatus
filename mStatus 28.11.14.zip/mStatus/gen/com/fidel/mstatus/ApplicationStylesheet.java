/**
 * Appcelerator Titanium
 * WARNING: This is a generated file.  Do not modify.
 */
package com.fidel.mstatus;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.appcelerator.titanium.TiStylesheet;

import org.appcelerator.kroll.KrollDict;

public final class ApplicationStylesheet extends TiStylesheet
{
	public ApplicationStylesheet()
	{
		super();

	}
}