package com.fidel.mstatus;

import org.appcelerator.titanium.ITiAppInfo;
import org.appcelerator.titanium.TiApplication;
import org.appcelerator.titanium.TiProperties;
import org.appcelerator.kroll.common.Log;

/* GENERATED CODE
 * Warning - this class was generated from your application's tiapp.xml
 * Any changes you make here will be overwritten
 */
public final class MstatusAppInfo implements ITiAppInfo
{
	private static final String LCAT = "AppInfo";

	public MstatusAppInfo(TiApplication app) {
	}

	public String getDeployType() {
		return "test";
	}

	public String getId() {
		return "com.fidel.mstatus";
	}

	public String getName() {
		return "mStatus";
	}

	public String getVersion() {
		return "1.0";
	}

	public String getPublisher() {
		return "sachin";
	}

	public String getUrl() {
		return "http://";
	}

	public String getCopyright() {
		return "2014 by sachin";
	}

	public String getDescription() {
		return "";
	}

	public String getIcon() {
		return "appicon.png";
	}

	public boolean isAnalyticsEnabled() {
		return true;
	}

	public String getGUID() {
		return "46f5930c-0ec4-4825-a098-1bbc856e84b4";
	}

	public boolean isFullscreen() {
		return false;
	}

	public String getBuildType() {
		return "";
	}
}
