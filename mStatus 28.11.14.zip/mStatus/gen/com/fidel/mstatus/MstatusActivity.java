package com.fidel.mstatus;

import org.appcelerator.titanium.TiRootActivity;

public final class MstatusActivity extends TiRootActivity
{
}
